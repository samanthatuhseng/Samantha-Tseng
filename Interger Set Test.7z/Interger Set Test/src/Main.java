public class Main {
    public static void main(String[] args) {
        IntegerSet mySet = new IntegerSet();
        mySet.insert(3);
        mySet.insert(3);
        mySet.size();
        mySet.contains(3);
        mySet.remove(3);

    }
}
