import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertTrue;

public class customerTest {
    Customer testSet;
@Before
public void setup(){
    testSet = new Customer();
}

@Test

    public void testDeposit(){

}



}
